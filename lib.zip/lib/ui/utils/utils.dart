
import '../../application/network/external_values/iExternalValue.dart';
import '../../di/di.dart';

class Utils {
  late IExternalValues _iExternal;
  Utils() {
    _iExternal = inject<IExternalValues>();
  }

  // String symbolText(dynamic text, String symbol, [bool isAfter = true]) {
  //   return text == null
  //       ? '-'
  //       : isAfter
  //           ? '${NumberFormat.decimalPattern().format(text)} $symbol'
  //           : '$symbol ${NumberFormat.decimalPattern().format(text)}';
  // }

  double cast(int? value) => value?.toDouble() ?? 0.0;

  String compactText(dynamic value) => value == null ? '-' : value.toString();

  T compactEnumText<T>(int? value, T) => value == null ? '-' : T[value];

  String attachBaseUrl(String path) {
    return "${_iExternal.getBaseUrl()}/$path";
  }
}

abstract class IExternalValues {
  String getBaseUrl();
  String countriesBaseUrl();
}



import 'package:memorylif/ui/base/base_view_model.dart';


class AppViewModel extends BaseViewModel {

}
